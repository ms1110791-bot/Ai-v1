package com.myai.assistant

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** सारी settings और API keys यहाँ (encrypted) सेव होती हैं। नई setting जोड़नी हो तो DEFAULTS में जोड़ो। */
class Prefs(ctx: Context) {

    companion object {
        val DEFAULTS = mapOf(
            "wake" to "jarvis, जार्विस",
            "lang" to "hi-IN",
            "geminiKey" to "",
            "geminiModel" to "gemini-2.5-flash",
            "searchKey" to "",
            "searchCx" to "",
            "elevenKey" to "",
            "elevenVoice" to "21m00Tcm4TlvDq8ikWAM",
            "elevenModel" to "eleven_flash_v2_5"
        )
    }

    private val sp: SharedPreferences = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secure_prefs", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("plain_prefs", Context.MODE_PRIVATE)
    }

    fun get(k: String): String =
        sp.getString(k, null)?.takeIf { it.isNotBlank() } ?: DEFAULTS[k] ?: ""

    fun put(k: String, v: String) {
        sp.edit().putString(k, v.trim()).apply()
    }

    val wakeName get() = get("wake")
    val lang get() = get("lang")
    val geminiKey get() = get("geminiKey")
    val geminiModel get() = get("geminiModel")
    val searchKey get() = get("searchKey")
    val searchCx get() = get("searchCx")
    val elevenKey get() = get("elevenKey")
    val elevenVoice get() = get("elevenVoice")
    val elevenModel get() = get("elevenModel")
}
