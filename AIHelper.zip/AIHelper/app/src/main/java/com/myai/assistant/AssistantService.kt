package com.myai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * हमेशा चलने वाली सर्विस: AI का नाम सुनती है → फ्लोटिंग विंडो खोलती है → कमांड सुनकर जवाब देती है।
 * ऑफलाइन: फ़ोन-कमांड। ऑनलाइन: Gemini + लाइव सर्च + ElevenLabs आवाज़।
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.myai.assistant.STOP"
        private const val CH = "assistant"
        private val NEEDS_SEARCH = Regex(
            "search|सर्च|खोज|google|गूगल|news|न्यूज|समाचार|latest|आज|aaj|अभी|abhi|price|भाव|कीमत|weather|मौसम|score|स्कोर|live|लाइव",
            RegexOption.IGNORE_CASE
        )

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java))
        }
    }

    private enum class Mode { WAKE, COMMAND, FOLLOWUP }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var prefs: Prefs
    private lateinit var llm: LlmProvider
    private lateinit var search: SearchProvider
    private lateinit var voice: VoiceRouter
    private lateinit var device: DeviceController
    private var ui: FloatingUi? = null
    private var rec: SpeechRecognizer? = null
    private val history = mutableListOf<Pair<String, String>>()
    private var running = false
    private var busy = false
    private var woke = false
    private var job: Job? = null
    private val hideTask = Runnable { ui?.hide() }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        // ↓ अपग्रेड के लिए बस यही तीन लाइनें बदलनी हैं (नया मॉडल / नया सर्च / नई आवाज़)
        llm = GeminiLlm(prefs)
        search = GoogleSearch(prefs)
        voice = VoiceRouter(this, prefs)
        device = DeviceController(this)
        ui = FloatingUi(
            this,
            onSend = { t -> if (!busy) handle(t) },
            onMic = {
                if (!busy) {
                    try { rec?.cancel() } catch (_: Exception) {}
                    listen(Mode.COMMAND)
                }
            },
            onClose = { ui?.hide() }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Assistant", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle(prefs.wakeName.split(",").first().trim() + " सुन रहा है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "रोको", stop).build())
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (!running) {
            running = true
            listen(Mode.WAKE)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        scope.cancel()
        try { rec?.destroy() } catch (_: Exception) {}
        voice.stop()
        ui?.hide()
        super.onDestroy()
    }

    // ---------- सुनना ----------

    private fun listen(mode: Mode) {
        if (!running || busy) return
        main.post {
            if (!running || busy) return@post
            try { rec?.destroy() } catch (_: Exception) {}
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                ui?.setStatus("Speech recognition उपलब्ध नहीं है")
                return@post
            }
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            rec = r
            r.setRecognitionListener(Listener(mode))
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !isOnline())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            r.startListening(i)
        }
    }

    private fun retry(mode: Mode, delayMs: Long = 250) {
        main.postDelayed({ listen(mode) }, delayMs)
    }

    private fun names(): List<String> =
        prefs.wakeName.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    private fun hasWake(t: String): Boolean {
        val l = t.lowercase()
        return names().any { l.contains(it) }
    }

    private fun stripWake(t: String): String {
        val l = t.lowercase()
        for (n in names()) {
            val idx = l.indexOf(n)
            if (idx >= 0) return t.substring(idx + n.length).trim().trimStart(',', '.', '!', '?', ' ')
        }
        return t.trim()
    }

    private inner class Listener(val mode: Mode) : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (mode != Mode.WAKE) ui?.setStatus("सुन रहा हूँ…")
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            if (mode != Mode.WAKE || woke) return
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (hasWake(t)) {
                woke = true
                showUi() // नाम सुनते ही विंडो तुरंत खुल जाए
            }
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (mode == Mode.WAKE) {
                if (woke || hasWake(t)) {
                    woke = false
                    showUi()
                    val rest = stripWake(t)
                    if (rest.isNotBlank()) handle(rest) else listen(Mode.COMMAND)
                } else {
                    listen(Mode.WAKE)
                }
            } else {
                if (t.isBlank()) idleBack() else handle(t)
            }
        }

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                ui?.setStatus("Mic permission दो")
                stopSelf()
                return
            }
            if (mode == Mode.WAKE) {
                if (woke) {
                    woke = false
                    listen(Mode.COMMAND)
                } else {
                    retry(Mode.WAKE, if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 250)
                }
            } else {
                idleBack()
            }
        }
    }

    private fun idleBack() {
        ui?.setStatus("नाम लेकर बुलाओ")
        main.postDelayed(hideTask, 12000)
        retry(Mode.WAKE)
    }

    private fun showUi() {
        if (!Settings.canDrawOverlays(this)) return
        main.removeCallbacks(hideTask)
        ui?.show(prefs.wakeName.split(",").first().trim())
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val nc = cm.getNetworkCapabilities(cm.activeNetwork)
        return nc?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }

    // ---------- सोचना + करना + बोलना ----------

    private fun handle(text: String) {
        if (busy) return
        busy = true
        try { rec?.cancel() } catch (_: Exception) {}
        showUi()
        ui?.append("you", text)
        ui?.setStatus("सोच रहा हूँ…")

        job = scope.launch {
            var reply = ""
            var premium = true
            val online = isOnline()
            try {
                val local = OfflineMatcher.match(text)
                if (local != null) {
                    val notes = local.mapNotNull { device.run(it) }
                    reply = if (notes.isEmpty()) "हो गया" else notes.joinToString(". ")
                    premium = false
                } else if (!online) {
                    reply = "इंटरनेट नहीं है। अभी सिर्फ़ फ़ोन कमांड चलेंगे, जैसे वाई-फाई, वॉल्यूम, टॉर्च।"
                    premium = false
                } else if (prefs.geminiKey.isBlank()) {
                    reply = "पहले Settings में Gemini key डालो"
                    premium = false
                } else {
                    val web = if (prefs.searchKey.isNotBlank() && NEEDS_SEARCH.containsMatchIn(text)) {
                        try { search.search(text) } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
                    } else null
                    val raw = llm.ask(text, history, web, grounding = web == null)
                    val (spoken, acts) = ActionParser.parse(raw)
                    val notes = acts.mapNotNull { device.run(it) }
                    reply = if (spoken.isNotBlank()) spoken else if (notes.isEmpty()) "ठीक है" else notes.joinToString(". ")
                    history.add("user" to text)
                    history.add("model" to reply)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                reply = "एरर: " + (e.message ?: "unknown").take(80)
                premium = false
            }
            ui?.append("ai", reply)
            ui?.setStatus("बोल रहा हूँ…")
            try {
                voice.speak(reply, premium, online)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // आवाज़ फेल हुई तो भी टेक्स्ट विंडो में दिख चुका है
            }
            busy = false
            ui?.setStatus("सुन रहा हूँ…")
            listen(Mode.FOLLOWUP)
        }
    }
}
