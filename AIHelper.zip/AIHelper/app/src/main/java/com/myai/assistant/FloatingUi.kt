package com.myai.assistant

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** AI का नाम बोलते ही दिखने वाली तैरती (floating) चैट + वॉइस विंडो। हेडर पकड़कर खिसका सकते हो। */
class FloatingUi(
    private val ctx: Context,
    private val onSend: (String) -> Unit,
    private val onMic: () -> Unit,
    private val onClose: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: View? = null
    private var log: TextView? = null
    private var status: TextView? = null
    private var scroll: ScrollView? = null

    private val lp = WindowManager.LayoutParams(
        dp(320), WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(20)
        y = dp(120)
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun show(name: String) {
        if (root != null) return
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(0xF2101820.toInt())
                cornerRadius = dp(18).toFloat()
            }
        }

        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(ctx).apply {
            text = "● $name"
            setTextColor(0xFF7CF5C8.toInt())
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val close = TextView(ctx).apply {
            text = "✕"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { onClose() }
        }
        head.addView(title)
        head.addView(close)

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        head.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(col, lp)
                }
            }
            true
        }

        val st = TextView(ctx).apply {
            setTextColor(0xFF9AA7B2.toInt())
            textSize = 12f
            text = "सुन रहा हूँ…"
        }
        val lg = TextView(ctx).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setPadding(0, dp(4), 0, dp(4))
        }
        val sc = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160))
            addView(lg)
        }

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(ctx).apply {
            hint = "यहाँ लिखो…"
            setHintTextColor(0xFF6B7782.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            maxLines = 2
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        input.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                wm.updateViewLayout(col, lp)
            }
            false
        }
        fun send() {
            val t = input.text.toString().trim()
            input.setText("")
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            wm.updateViewLayout(col, lp)
            (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(input.windowToken, 0)
            if (t.isNotEmpty()) onSend(t)
        }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }
        val mic = Button(ctx).apply {
            text = "🎤"
            setOnClickListener { onMic() }
        }
        val go = Button(ctx).apply {
            text = "➤"
            setOnClickListener { send() }
        }
        row.addView(input)
        row.addView(mic, LinearLayout.LayoutParams(dp(52), dp(44)))
        row.addView(go, LinearLayout.LayoutParams(dp(52), dp(44)))

        col.addView(head)
        col.addView(st)
        col.addView(sc)
        col.addView(row)

        wm.addView(col, lp)
        root = col
        log = lg
        status = st
        scroll = sc
    }

    fun hide() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        log = null
        status = null
        scroll = null
    }

    fun append(who: String, text: String) {
        val icon = if (who == "you") "🧑" else "🤖"
        log?.append("$icon $text\n")
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    fun setStatus(s: String) {
        status?.text = s
    }
}
