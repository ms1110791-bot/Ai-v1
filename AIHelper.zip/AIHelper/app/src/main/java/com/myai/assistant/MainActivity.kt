package com.myai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Settings स्क्रीन: AI का नाम, API keys (Gemini / Search / ElevenLabs) और permissions। */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val fields = LinkedHashMap<String, EditText>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(32))
        }
        col.addView(TextView(this).apply { text = "AI Helper"; textSize = 24f })
        col.addView(TextView(this).apply {
            text = "AI का नाम बोलो → विंडो खुलेगी → काम होगा।"
            setPadding(0, dp(4), 0, dp(12))
        })

        field(col, "wake", "AI का नाम / wake word (कॉमा से कई नाम)", false)
        field(col, "lang", "भाषा कोड (hi-IN / en-IN)", false)
        field(col, "geminiKey", "Gemini API key", true)
        field(col, "geminiModel", "Gemini model (बदलकर अपग्रेड कर सकते हो)", false)
        field(col, "searchKey", "Google Search API key (optional)", true)
        field(col, "searchCx", "Google Search Engine ID — cx (optional)", false)
        field(col, "elevenKey", "ElevenLabs API key", true)
        field(col, "elevenVoice", "ElevenLabs Voice ID", false)
        field(col, "elevenModel", "ElevenLabs model", false)

        col.addView(button("सेव करो + असिस्टेंट शुरू करो") { saveAndStart() })
        col.addView(button("रोको") {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
        })
        col.addView(TextView(this).apply {
            text = "\nPermissions (एक बार देनी हैं):"
            setPadding(0, dp(8), 0, dp(4))
        })
        col.addView(button("1) Overlay (फ्लोटिंग विंडो)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("2) Accessibility (फ़ोन कंट्रोल)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("3) Write settings (ब्राइटनेस)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(button("4) Battery: Unrestricted करो") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun field(parent: LinearLayout, key: String, label: String, secret: Boolean) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 13f
            setPadding(0, dp(10), 0, 0)
        })
        val e = EditText(this).apply {
            setText(prefs.get(key))
            setSingleLine()
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT
        }
        fields[key] = e
        parent.addView(e)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun saveAndStart() {
        fields.forEach { (k, v) -> prefs.put(k, v.text.toString()) }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
        } else {
            startAssistant()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startAssistant()
        } else {
            Toast.makeText(this, "Mic permission ज़रूरी है", Toast.LENGTH_LONG).show()
        }
    }

    private fun startAssistant() {
        AssistantService.start(this)
        Toast.makeText(this, "शुरू! अब नाम बोलकर बुलाओ", Toast.LENGTH_LONG).show()
    }
}
