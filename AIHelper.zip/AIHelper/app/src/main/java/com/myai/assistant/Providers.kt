package com.myai.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.coroutines.resume

/*
 * अपग्रेड कैसे करें: नया मॉडल/सर्विस चाहिए तो नीचे का interface implement करो
 * और AssistantService.onCreate() में एक लाइन बदल दो। बाकी कोड नहीं छूना पड़ेगा।
 */
interface LlmProvider {
    suspend fun ask(user: String, history: List<Pair<String, String>>, webContext: String?, grounding: Boolean): String
}

interface SearchProvider {
    suspend fun search(q: String): String?
}

interface VoiceProvider {
    suspend fun speak(text: String)
    fun stop()
}

object Http {
    fun request(
        url: String,
        method: String = "GET",
        body: String? = null,
        headers: Map<String, String> = emptyMap(),
        timeoutMs: Int = 20000
    ): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code !in 200..299) throw RuntimeException("HTTP $code: " + String(bytes).take(200))
            return bytes
        } finally {
            c.disconnect()
        }
    }
}

/** Gemini: चैट + (जरूरत पड़े तो) Google Search grounding से लाइव जानकारी। */
class GeminiLlm(private val p: Prefs) : LlmProvider {
    override suspend fun ask(
        user: String,
        history: List<Pair<String, String>>,
        webContext: String?,
        grounding: Boolean
    ): String = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        history.takeLast(6).forEach { (role, text) ->
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val finalUser = if (webContext != null) user + "\n\n[Web results]\n" + webContext else user
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", finalUser)))
        )
        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Prompts.system(p.wakeName.split(",").first().trim()))))
            )
            .put("contents", contents)
        if (grounding) {
            body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" + p.geminiModel + ":generateContent"
        val res = Http.request(
            url, "POST", body.toString(),
            mapOf("Content-Type" to "application/json", "x-goog-api-key" to p.geminiKey)
        )
        val parts = JSONObject(String(res))
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        buildString {
            for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
        }.trim()
    }
}

/** Google Custom Search API (optional). Key + cx डालने पर चालू होता है। */
class GoogleSearch(private val p: Prefs) : SearchProvider {
    override suspend fun search(q: String): String? = withContext(Dispatchers.IO) {
        if (p.searchKey.isBlank() || p.searchCx.isBlank()) return@withContext null
        val url = "https://www.googleapis.com/customsearch/v1?key=" + enc(p.searchKey) +
                "&cx=" + enc(p.searchCx) + "&num=5&q=" + enc(q)
        val items = JSONObject(String(Http.request(url))).optJSONArray("items") ?: return@withContext null
        buildString {
            for (i in 0 until items.length()) {
                val o = items.getJSONObject(i)
                append("- ").append(o.optString("title")).append(": ")
                    .append(o.optString("snippet")).append(" (").append(o.optString("link")).append(")\n")
            }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}

/** ElevenLabs की आवाज़ (ऑनलाइन)। */
class ElevenVoice(private val ctx: Context, private val p: Prefs) : VoiceProvider {
    private var mp: MediaPlayer? = null

    override suspend fun speak(text: String) {
        val f = File(ctx.cacheDir, "tts.mp3")
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("text", text).put("model_id", p.elevenModel).toString()
            val bytes = Http.request(
                "https://api.elevenlabs.io/v1/text-to-speech/" + p.elevenVoice + "?output_format=mp3_44100_64",
                "POST", body,
                mapOf("xi-api-key" to p.elevenKey, "Content-Type" to "application/json")
            )
            f.writeBytes(bytes)
        }
        suspendCancellableCoroutine<Unit> { cont ->
            val m = MediaPlayer()
            mp = m
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            m.setDataSource(f.absolutePath)
            m.setOnCompletionListener {
                m.release(); mp = null
                if (cont.isActive) cont.resume(Unit)
            }
            m.setOnErrorListener { _, _, _ ->
                m.release(); mp = null
                if (cont.isActive) cont.resume(Unit)
                true
            }
            m.setOnPreparedListener { it.start() }
            m.prepareAsync()
            cont.invokeOnCancellation { try { m.release() } catch (_: Exception) {} }
        }
    }

    override fun stop() {
        try { mp?.stop(); mp?.release() } catch (_: Exception) {}
        mp = null
    }
}

/** फ़ोन की अपनी आवाज़ (ऑफलाइन चलती है)। */
class AndroidVoice(ctx: Context, private val p: Prefs) : VoiceProvider {
    private var ready = false
    private var pending: (() -> Unit)? = null
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) {
                pending?.invoke()
                pending = null
            }
        }
    }

    override suspend fun speak(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        fun run() {
            tts.setLanguage(Locale.forLanguageTag(p.lang))
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
                override fun onError(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
            })
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, System.nanoTime().toString())
        }
        if (ready) run() else pending = { run() }
        cont.invokeOnCancellation { tts.stop() }
    }

    override fun stop() {
        try { tts.stop() } catch (_: Exception) {}
    }
}

/** ऑनलाइन + ElevenLabs key हो तो ElevenLabs, वरना फ़ोन की आवाज़। */
class VoiceRouter(ctx: Context, private val p: Prefs) {
    private val eleven = ElevenVoice(ctx, p)
    private val local = AndroidVoice(ctx, p)

    suspend fun speak(text: String, premium: Boolean, online: Boolean) {
        if (text.isBlank()) return
        if (premium && online && p.elevenKey.isNotBlank()) {
            try {
                eleven.speak(text)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // ElevenLabs फेल हुआ → फ़ोन की आवाज़ से बोलो
            }
        }
        local.speak(text)
    }

    fun stop() {
        eleven.stop()
        local.stop()
    }
}
