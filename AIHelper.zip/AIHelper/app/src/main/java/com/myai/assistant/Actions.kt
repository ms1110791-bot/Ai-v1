package com.myai.assistant

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.webkit.URLUtil

/** एक डिवाइस-काम। type: open, download, web, setting, volume, brightness, torch, click, type, scroll, back, home ... */
data class Act(val type: String, val arg: String = "")

object Prompts {
    fun system(name: String): String = """
You are ${name}, a very fast voice assistant living on the user's Android phone.
Reply in the user's language (Hindi / Hinglish / English). Maximum 2 short sentences, plain speech, no markdown, no emojis.
Use live web information for current facts.
To act on the phone, add tags at the very end of your reply, only if the user asked for that action:
[[open:App Name]] [[download:URL]] [[web:URL]] [[setting:wifi|bluetooth|display|sound|battery|location|airplane|apps|ram]]
[[volume:0-100]] [[brightness:0-100]] [[torch:on|off]] [[click:visible text]] [[type:text]] [[scroll:down|up]]
[[back]] [[home]] [[recents]] [[notifications]] [[lock]] [[screenshot]]
""".trimIndent()
}

object ActionParser {
    private val tag = Regex("\\[\\[(\\w+)(?::([^\\]]*))?\\]\\]")

    /** (बोलने वाला टेक्स्ट, चलाने वाले काम) */
    fun parse(raw: String): Pair<String, List<Act>> {
        val acts = tag.findAll(raw).map { Act(it.groupValues[1].lowercase(), it.groupValues[2].trim()) }.toList()
        return tag.replace(raw, "").trim() to acts
    }
}

/** ऑफलाइन (बिना इंटरनेट) फ़ोन-कमांड पहचानने वाला हल्का मैचर। Hindi + Hinglish + English। */
object OfflineMatcher {
    private val num = Regex("\\d{1,3}")
    private val url = Regex("https?://\\S+")

    private fun has(t: String, vararg words: String): Boolean = words.any { w ->
        if (w.length <= 5 && w.all { it in 'a'..'z' }) Regex("\\b" + Regex.escape(w) + "\\b").containsMatchIn(t)
        else t.contains(w)
    }

    fun match(raw: String): List<Act>? {
        val t = raw.lowercase().trim()
        if (t.isBlank()) return null

        // download + लिंक
        url.find(t)?.let { if (has(t, "download", "डाउनलोड")) return listOf(Act("download", it.value)) }

        // ऐप खोलो
        val pre = Regex("^(open|launch|start)\\s+(.+)$").find(t)
        val post = Regex("^(.+?)\\s+(kholo|khol do|khol|खोलो|खोल दो|खोल|open kar do|open karo|chalu karo|चालू करो)$").find(t)
        val app = pre?.groupValues?.get(2) ?: post?.groupValues?.get(1)
        if (app != null && app.split(" ").size <= 3) return listOf(Act("open", app.trim()))

        if (t.split(" ").size > 9) return null // लंबा सवाल = AI के लिए

        val off = has(t, "band", "बंद", "बन्द", "off", "ऑफ")
        val n = num.find(t)?.value

        return when {
            has(t, "wifi", "wi-fi", "वाईफाई", "वाई-फाई", "वाई फाई") -> listOf(Act("setting", "wifi"))
            has(t, "bluetooth", "ब्लूटूथ") -> listOf(Act("setting", "bluetooth"))
            has(t, "torch", "flashlight", "टॉर्च", "फ्लैशलाइट") -> listOf(Act("torch", if (off) "off" else "on"))
            has(t, "brightness", "ब्राइटनेस") ->
                listOf(Act("brightness", n ?: if (has(t, "kam", "कम", "low")) "20" else "100"))
            has(t, "volume", "वॉल्यूम", "आवाज़", "आवाज", "awaaz") -> when {
                n != null -> listOf(Act("volume", n))
                has(t, "mute", "silent", "म्यूट", "band", "बंद") -> listOf(Act("volume", "0"))
                has(t, "kam", "कम", "down", "low") -> listOf(Act("volumestep", "down"))
                else -> listOf(Act("volumestep", "up"))
            }
            has(t, "ram", "रैम", "memory", "मेमोरी") -> listOf(Act("setting", "ram"))
            has(t, "battery", "बैटरी") -> listOf(Act("setting", "battery"))
            has(t, "airplane", "flight mode", "एयरप्लेन") -> listOf(Act("setting", "airplane"))
            has(t, "screenshot", "स्क्रीनशॉट") -> listOf(Act("screenshot"))
            has(t, "notification", "नोटिफिकेशन") -> listOf(Act("notifications"))
            has(t, "recent", "रिसेंट") -> listOf(Act("recents"))
            has(t, "scroll", "स्क्रोल", "नीचे", "ऊपर") ->
                listOf(Act("scroll", if (has(t, "up", "ऊपर")) "up" else "down"))
            has(t, "back", "वापस", "पीछे") -> listOf(Act("back"))
            has(t, "home", "होम") -> listOf(Act("home"))
            has(t, "lock", "लॉक") -> listOf(Act("lock"))
            else -> null
        }
    }
}

/** असली काम यहाँ होते हैं। सफल हो तो null, वरना बोलने लायक छोटा संदेश लौटता है। */
class DeviceController(private val ctx: Context) {

    private val needAcc = "पहले Accessibility सर्विस चालू करो"

    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp",
        "इंस्टाग्राम" to "instagram", "क्रोम" to "chrome", "कैमरा" to "camera", "सेटिंग" to "settings",
        "सेटिंग्स" to "settings", "गैलरी" to "gallery", "फोन" to "phone", "जीमेल" to "gmail",
        "मैप्स" to "maps", "फेसबुक" to "facebook", "टेलीग्राम" to "telegram", "स्नैपचैट" to "snapchat",
        "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "प्ले स्टोर" to "play store"
    )

    fun run(a: Act): String? = try {
        exec(a)
    } catch (e: Exception) {
        "नहीं हो पाया"
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun exec(a: Act): String? = when (a.type) {
        "open" -> openApp(a.arg)
        "web" -> { start(Intent(Intent.ACTION_VIEW, Uri.parse(a.arg))); null }
        "download" -> download(a.arg)
        "setting" -> { openSetting(a.arg); null }
        "volume" -> { setVolume(a.arg.toIntOrNull() ?: 50); null }
        "volumestep" -> { stepVolume(a.arg == "up"); null }
        "brightness" -> brightness(a.arg.toIntOrNull() ?: 50)
        "torch" -> torch(a.arg == "on")
        "back" -> acc { it.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) }
        "home" -> acc { it.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) }
        "recents" -> acc { it.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS) }
        "notifications" -> acc { it.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }
        "lock" -> acc { it.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) }
        "screenshot" -> acc { it.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) }
        "click" -> acc { it.clickText(a.arg) }
        "type" -> acc { it.typeText(a.arg) }
        "scroll" -> acc { it.scroll(a.arg != "up") }
        else -> "ये काम मुझे नहीं आता"
    }

    private fun acc(block: (ControlService) -> Boolean): String? {
        val c = ControlService.instance ?: return needAcc
        return if (block(c)) null else "स्क्रीन पर नहीं मिला"
    }

    private fun openApp(nameRaw: String): String? {
        var want = nameRaw.lowercase().trim()
        aliases.forEach { (k, v) -> if (want.contains(k)) want = v }
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(q, 0).firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase()
            l.contains(want) || (l.length >= 3 && want.contains(l))
        } ?: return "ऐप नहीं मिला"
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "ऐप नहीं खुला"
        start(i)
        return null
    }

    private fun download(u: String): String? {
        if (!u.startsWith("http")) return "लिंक सही नहीं है"
        val req = DownloadManager.Request(Uri.parse(u))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(u, null, null))
        (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        return null
    }

    private fun openSetting(name: String) {
        val action = when (name.lowercase()) {
            "wifi", "internet", "data" ->
                if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "ram", "memory", "developer" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action))
    }

    private fun audio() = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun setVolume(pct: Int) {
        val am = audio()
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, pct.coerceIn(0, 100) * max / 100, AudioManager.FLAG_SHOW_UI)
    }

    private fun stepVolume(up: Boolean) {
        val am = audio()
        repeat(2) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
    }

    private fun brightness(pct: Int): String? {
        if (!Settings.System.canWrite(ctx)) {
            start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return "ब्राइटनेस के लिए permission दो"
        }
        val cr = ctx.contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, pct.coerceIn(1, 100) * 255 / 100)
        return null
    }

    private fun torch(on: Boolean): String? {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "फ्लैश नहीं मिला"
        cm.setTorchMode(id, on)
        return null
    }
}
