# AI Helper (Android, Kotlin)

AI का नाम बोलो → फ्लोटिंग चैट+वॉइस विंडो खुलती है → काम होता है।

## APK बनाना
1. यह पूरा फ़ोल्डर GitHub repo में डालो (branch `main`).
2. Actions → "Build APK" चलेगा → Artifacts से `AIHelper-apk` डाउनलोड करो।

## पहली बार
1. ऐप खोलो → नाम और API keys भरो → "सेव करो + शुरू करो"।
2. 4 permissions दो (Overlay, Accessibility, Write settings, Battery)।

## बाद में अपग्रेड (बिना पूरा कोड छुए)
- नया Gemini मॉडल: Settings में model का नाम बदलो।
- नई आवाज़: ElevenLabs Voice ID बदलो।
- नया LLM/सर्च/आवाज़: `Providers.kt` में interface implement करो, `AssistantService.onCreate()` में एक लाइन बदलो।
- नया ऑफलाइन कमांड: `Actions.kt` → `OfflineMatcher` में एक लाइन जोड़ो।
- नया डिवाइस-काम: `DeviceController.exec()` में एक branch जोड़ो।
